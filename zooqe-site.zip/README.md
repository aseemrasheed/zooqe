# ZOOQE — Premium Kerala Pickles & Spices Storefront

A bespoke, production-quality, ultra-luxury e-commerce website built for **ZOOQE** with a strict **Deep Black & Metallic Chrome / Silver** aesthetic.

ZOOQE is a premium Kerala food brand specializing exclusively in:
1. **AUTHENTIC PICKLES (ACHAR)**
2. **SIGNATURE MALABAR SPICES**

---

## Brand Identity

* **Brand Name**: ZOOQE
* **Tagline**: *PREMIUM TASTE. DISTINCTLY ZOOQE.*
* **Heritage**: Authentic Kerala Pickles & Single-Origin Malabar Spices
* **Brand Colors**: Deep Black (`#000000`, `#050507`, `#0C0C0F`) & Brushed Metallic Chrome / Silver (`#FFFFFF`, `#E2E2E5`, `#8E8E93`)
* **Styling**: Minimalist, bold, sophisticated, luxury international appearance.

---

## Products Catalog (`js/data/products.js`)

### Pickles (Achar):
1. **Mango Pickle** — Authentic Kerala Spiced Mango Achar
2. **Lemon Pickle** — Slow-Cured Whole Lemons with Malabar Spices
3. **Fish Pickle** — Wild-Caught Seer Fish in Coastal Malabar Masala
4. **Beef Pickle** — Slow-Roasted Beef Chunks in Malabar Spices
5. **Garlic Pickle** — Whole Aged Garlic Cloves in Gingelly Oil

### Spices:
6. **Black Pepper** — Tellicherry Bold Whole Black Peppercorns
7. **Cardamom** — Jumbo Grade-A Fragrant Green Pods

### Gift Sets:
8. **Heritage Luxury Hamper** — Curated Box of Artisanal Pickles & Spices

---

## Product Management (`js/data/products.js`)

All product data, sizes (**100g, 250g, 500g, 1kg**), prices, stock, ingredients, and descriptions can be edited in one central file: [`js/data/products.js`](js/data/products.js).

---

## Configuration (`js/config.js`)

To update the WhatsApp number, currency, or shipping thresholds, edit [`js/config.js`](js/config.js):

```javascript
export const CONFIG = {
  brandName: 'ZOOQE',
  whatsappNumber: '916238463851', // ZOOQE Business WhatsApp Number
  currency: '$',                   // e.g. '$', '₹', 'AED', '£', '€'
  freeShippingThreshold: 100,      // Free delivery on orders over threshold
  standardShippingFee: 15          // Standard delivery fee if under threshold
};
```

---

## Local Development & Testing

Start local server:
```powershell
cd C:\Users\MuhammedAseem\.gemini\antigravity\scratch\zooqe-store
python -m http.server 8000
```
Open **`http://localhost:8000`** in your browser.
